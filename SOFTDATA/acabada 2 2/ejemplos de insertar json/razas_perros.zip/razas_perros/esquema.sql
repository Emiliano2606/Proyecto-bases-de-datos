CREATE TABLE grupo (
    id_grupo INTEGER PRIMARY KEY,
    grupo VARCHAR(255)
);

CREATE TABLE raza (
    id_raza INTEGER PRIMARY KEY,
    nombre VARCHAR(255),
    id_grupo INTEGER REFERENCES grupo(id_grupo),
    seccion VARCHAR(255),
    pais VARCHAR(255),
    url VARCHAR(255),
    imagen VARCHAR(255)
);

CREATE TABLE tamano (
    id_tamano INTEGER PRIMARY KEY,
    categoria VARCHAR(255)
);

CREATE TABLE raza_tamano (
    id_raza INTEGER REFERENCES raza(id_raza),
    id_tamano INTEGER REFERENCES tamano(id_tamano),
    PRIMARY KEY (id_raza, id_tamano)
);
